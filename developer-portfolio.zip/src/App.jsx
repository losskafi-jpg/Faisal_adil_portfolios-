
import { FaGithub, FaLinkedin } from 'react-icons/fa';
export default function App(){
return (
<div className="app">
<nav><h2>MD Imran Alam</h2></nav>
<section className="hero">
<div>
<h1>Software Developer</h1>
<p>Replace this text with your intro.</p>
<button>View Projects</button>
</div>
<div className="photo">YOUR PHOTO</div>
</section>

<section className="card">
<h2>About Me</h2>
<p>Replace with your details.</p>
</section>

<section className="grid">
<div className="card">SafeStree Project</div>
<div className="card">Inventory System</div>
<div className="card">University Website</div>
</section>

<footer>
<FaGithub/> <FaLinkedin/>
</footer>
</div>
)}
